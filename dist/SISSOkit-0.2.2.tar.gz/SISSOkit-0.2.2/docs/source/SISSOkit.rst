SISSOkit package
================

Submodules
----------

SISSOkit.cross\_validation module
---------------------------------

.. automodule:: SISSOkit.cross_validation
   :members:
   :undoc-members:
   :show-inheritance:

SISSOkit.evaluation module
--------------------------

.. automodule:: SISSOkit.evaluation
   :members:
   :undoc-members:
   :show-inheritance:

SISSOkit.notebook module
------------------------

.. automodule:: SISSOkit.notebook
   :members:
   :undoc-members:
   :show-inheritance:

SISSOkit.plot module
--------------------

.. automodule:: SISSOkit.plot
   :members:
   :undoc-members:
   :show-inheritance:

SISSOkit.utils module
---------------------

.. automodule:: SISSOkit.utils
   :members:
   :undoc-members:
   :show-inheritance:


Module contents
---------------

.. automodule:: SISSOkit
   :members:
   :undoc-members:
   :show-inheritance:
